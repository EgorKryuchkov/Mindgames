#!/usr/bin/env python3
from brain_games.games import game_progr


def main():
    game_progr.find_numb()


if __name__ == '__main__':
    main()
