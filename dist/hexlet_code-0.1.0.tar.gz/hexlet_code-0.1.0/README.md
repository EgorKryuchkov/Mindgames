This is study project which includes some easy exercizes for your brain.

[![Code Climate](https://codeclimate.com/github/EgorKryuchkov/Mindgames.png)](https://codeclimate.com/github/EgorKryuchkov/Mindgames)

Presentation of the brain_even game: https://asciinema.org/a/YmyiJsdgAFVf075FVL9XYHiEj
