# Mindgames
This is study project which includes some easy exercizes for your brain.

[![Code Climate](https://codeclimate.com/github/EgorKryuchkov/Mindgames.png)](https://codeclimate.com/github/EgorKryuchkov/Mindgames)

## Presentation of games:
 
1) brain-even: https://asciinema.org/a/J69DXKdH7KWiuA65nMfPurAQR
2) brain-calc: https://asciinema.org/a/AYeXTx33nSgacECsL3VWphlfu

