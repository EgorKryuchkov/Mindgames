This is study project which includes some easy exercizes for your brain. 
