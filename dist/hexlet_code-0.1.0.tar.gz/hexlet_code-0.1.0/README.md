This is study project which includes some easy exercizes for your brain.

[![Code Climate](https://codeclimate.com/github/EgorKryuchkov/Mindgames.png)](https://codeclimate.com/github/EgorKryuchkov/Mindgames)
